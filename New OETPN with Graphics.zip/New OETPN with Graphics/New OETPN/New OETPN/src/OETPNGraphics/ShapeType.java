package OETPNGraphics;

public enum ShapeType {
	Place, Transition, Arc
}
